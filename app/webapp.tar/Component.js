/* global hasher */
sap.ui.define([
    "sap/fe/AppComponent"
], function (AppComponent) {
    "use strict";

    return AppComponent.extend("corp.sap.Authors_V4.Component", {
        metadata: {
            "manifest": "json"
        }
    });
});
